To launch this test open two different consoles:

In the first one launch: HelloWorldExample publisher (or HelloWorldExample.exe publisher on windows).
In the second one: HelloWorldExample subscriber.


